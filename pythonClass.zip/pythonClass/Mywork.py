from tkinter import*

root=Tk()

# variable assignation
frame=Frame(root,height=150,width=200)
lab1=Label(frame,text="Information")
lab2=Label(frame,text="Username")
lab3=Label(frame,text="Password")

# griding the variables
lab1.grid()
lab2.grid()
lab3.grid()

# adding buttons
btn1=Button(frame,text="LOGIN")
btn1=Button(frame,text="SIGNUP")
btn1=Button(frame,text="QUIT")

#griding the buttons
btn1.grid()
btn1.grid()
btn1.grid()






root.mainloop()