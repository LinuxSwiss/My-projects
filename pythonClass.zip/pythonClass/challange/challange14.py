num = int(input("Enter a value between 10 and 20: "))
if num >= 10 and num <= 20:
   print("Thanks you") 
else:
    print("incorrect answer")   