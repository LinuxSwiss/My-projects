if num1 > 10:
    print("This is over 10")
    elif num1 == 10:
        print("This is equal to 10")
    else:
        print("This is under 10")