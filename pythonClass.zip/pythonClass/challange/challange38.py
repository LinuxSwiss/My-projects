num = int(input("Enter a number: "))
name = input("Enter your name: ")
for x in range (0,num):
    for i in name:
        print(1)