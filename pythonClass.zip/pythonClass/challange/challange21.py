firstname = input("Enter your first name: ")
surname = input("Enter your surname: ")
name = firstname + " " + surname 
length = len(name)
print(name)
print(lenght)