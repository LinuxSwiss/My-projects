firstName = input("enter your name: ")
print ("hello",firstname)