poem = "oh, I wish i'd looked after me teeth,"
print(poem)
start = int(input("enter a starting number: "))
end = int(input("enter an end number: "))
print(poem[start:end])