num1 = int(input("please enter your first number: "))
num2 = int(input("please enter your second number: "))
answer = num1 + num2
print ("The answer is",answer)