name = input("Enter your first name: ")
if len(name)< 5:
    surname = input("Enter your surname: ")
    name = name+surname
else:
    print(name.lower())
   