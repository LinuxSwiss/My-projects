num = [123,345,234,765]
for i in num:
    print(i)
    selection = int(input("enter a number from the list: "))
if selection in num:
    print(selection,"is in position",num.index(selection))
else:
    print("that is not in the list")