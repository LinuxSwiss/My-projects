pswd1 = input("enter a password: ")
pswd2 = input("enter it again: ")
if pswd1 == pswd2:
    print("thank you")
elif pswd1.lower() == pswd2.lower():
    print("they must be the same case")
else:
        print("incorrect")