name = input("Enter your name: ")
for i in name:
    print(1)