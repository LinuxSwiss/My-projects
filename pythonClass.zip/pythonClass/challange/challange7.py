name = input("What is your name ")
age = int(input("How old are you? "))
state = input("where are you from ")
newAge = age + 1
print(name, "next birthday you will be", newAge)