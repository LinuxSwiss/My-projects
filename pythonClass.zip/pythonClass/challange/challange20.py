name = input("enter your first name: ")
lenght = len(name)
print(length)