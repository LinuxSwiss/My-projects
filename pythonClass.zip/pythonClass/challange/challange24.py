word = input("Enter a word: ")
word = word.upper()
print(word)