msg = input("enter a message in uppercase: ")
tryagain = False
while tryagain == False:
    if msg.isupper():
        print("thank you")
        tryagain = True
    else:
        print("try again")
        msg = input("enter a message in uppercase: ")