import random
num = random.randict (1,100)
print (num)