import turtle

for i in range (0,5):
turtle.forward(100)
turtle.right(144)

turtle.exitonclick()