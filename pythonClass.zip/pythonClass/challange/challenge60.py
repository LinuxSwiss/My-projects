import turtle

for i in range(0,40):
    turtle.forward(100)
    turtle.right(90)

    turtle.exitonclick()
