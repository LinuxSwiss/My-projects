colours = ["red","blue","green","black","white","pink","grey","purple","yellow","brown"]
start = int(input("enter a starting number (0-4): "))
end = int(input("enter an end number (5-9): "))
print(colours[start:end])