sports_list = ["tennis","football"]
sports_list.append(input("What is your favourite sport?"))
sports_list.sort()
print(sports_list)