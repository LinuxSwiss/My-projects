colour = input("Type in ypur favourite colour: ")
if colour == "red" or colour == "RED" or colour == "Red":
    print("Thank you")
else:
    print("incorrect answer")    