import random
coin = random.choice( ["h", "t"] )
guess = input("Enter (h)eads or (t)ails: ")
if guess == coin:
    print("You win")
else:
    print("Bad luck")
if coin  == "h":
    print("It was heads")
else:
    print("It was tails")