startNum = int(input("enter the number of slices of the pizza you started with: "))
endNum = int(input("How many slices have you eaten? "))
slicesleft = startNum - endNum
print ("you have", slicesleft, "slices remaining")