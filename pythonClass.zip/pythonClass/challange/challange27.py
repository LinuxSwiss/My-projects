num = float(input("Enter a number with lots of decimal places: "))
print(num*2)