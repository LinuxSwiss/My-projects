import math
radius = int(input("Enter the radius of the circle: "))
area = math.pi*(radius**2)
print(area)