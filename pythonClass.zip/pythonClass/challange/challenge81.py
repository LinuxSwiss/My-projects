subject = input("enter your favourite school subject: ")#
for letter in subject:
    print(letter,end = "-")