firstname = input("please enter your name: ")
surename = input("please enter your surename: ")
print ("Hello", firstname, surename)