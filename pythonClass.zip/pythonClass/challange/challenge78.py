tv = ["task master","top gear","the big bang theory","how I met your mother"]
for i in tv:
    print (1)
print()
newtv = input("enter another TV show: ")
position = int(input("enter a number between 0 and 3: "))
tv.insert(position,newtv)
for i in tv:
    print (i)
    