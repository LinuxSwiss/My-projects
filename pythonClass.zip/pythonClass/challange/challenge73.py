food_dictionary = {}
food1 = input("enter a food you like: ")
food_dictionary[1] = food1
food2 = input("enter another food you like: ")
food_dictionary[2] = food2
food3 = input("enter a third food you like: ")
food_dictionary[3] = food3
food4 = input("enter the one last food that you like:")
food_dictionary[4] = food4
print(food_dictionary)
dislike = int(input("which one of this do you want to get rid of? "))
del food_dictionary[dislike]
print(sorted(food_dictionary[dislike]))
print(sorted(food_dictionary.values()))