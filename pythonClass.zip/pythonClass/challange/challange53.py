import random
fruit = random.choice(['apple', 'orange', 'grape', 'banana', 'srawberry'] )
print(fruit)