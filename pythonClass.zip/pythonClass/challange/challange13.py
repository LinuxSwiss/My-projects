num = int(input("enter a value less than 20: "))
if num >= 20:
    print("Too high")
else:
    print("Thank you")