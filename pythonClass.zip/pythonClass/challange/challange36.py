name = input("Type in your name: ")
number = int(input("Enter a number: "))
for i in range (0,number):
    print(name)