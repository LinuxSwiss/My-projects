fname = input("enter your first name: ")
print("that has", len(fname),"characters in it")
sname = input("enter your surname: ")
print("that has", len(sname),"characters in it")
name = fname + " " + sname
print("that has", len(name),"characters in it")