from array import *
nums = array('i',{})
for i in range (0,5):
    num = int(input("Enter a number: "))
    nums.append(num)
nums = sorted(nums)
num.reverse()
print(nums)
