total = 0
while total <= 50:
    num = int(input("Enter a number: "))
    total = total + num 
    print("The last number you entered was a", num)