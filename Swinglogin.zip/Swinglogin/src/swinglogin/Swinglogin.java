
package swinglogin;

import javax.swing.*;
import java.awt.*;

public class Swinglogin extends JFrame {
    JLabel info = new JLabel("        WELCOME TO MY LOGIN        "),
           fill = new JLabel("                              fill the gaps                                 "),
           ulab = new JLabel("Username:    "),
           plab = new JLabel("Password: ");
    JTextField txt = new JTextField(20);
    JPasswordField pas = new JPasswordField(20);
    JButton bnt = new JButton("LOGIN");
    JButton cancel = new JButton("CANCEL");
    JButton signup = new JButton("SIGNUP");
    
    public Swinglogin(){ 
    setTitle("Linux Swiss");
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setSize(260,300);
    setLocationRelativeTo(null);
    JPanel mas = new JPanel();
    mas.setBackground(Color.GRAY);
    mas.add(info);
    info.setForeground(Color.white);
    mas.add(fill);
    mas.add(ulab);
    mas.add(txt);
    mas.add(plab);
    mas.add(pas);
    mas.add(bnt);
    mas.add(cancel);
    mas.add(signup);
    add(mas);
    
    
    setVisible(true);
    
    
    }
    
    
            
            
    

   
    public static void main(String[] args) {
        Swinglogin cm = new Swinglogin();
    }
    
}
