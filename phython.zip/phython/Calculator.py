from tkinter import*

root=Tk()
root.title("Calculator")
root.configure(background="light blue")
root.geometry("400x500")
root.resizable(False, False)
entry=Entry(root,show=0)
entry.grid(columnspan=9, ipady="20",ipadx="150")

# for specil char
button1=Button(root,text="M",bd=8,padx="10",relief="flat")
button2=Button(root,text="MS-",bd=8,padx="10",relief="flat")
button3=Button(root,text="M",bd=8,padx="10",relief="flat")
button4=Button(root,text="M+",bd=8, padx="10",relief="flat")


button1.grid(row=1,column=4)
button2.grid(row=1,column=3)
button3.grid(row=1,column=2)
button4.grid(row=1,column=1)

# for numbers
button5=Button(root,text="%",bd=6,padx=25,relief="flat")
button6=Button(root,text="/-",bd=6,padx=25,relief="flat")
button7=Button(root,text="x",bd=6,padx=25,relief="flat")
button8=Button(root,text="1/x",bd=6,padx=25,relief="flat")
button9=Button(root,text="CE",bd=6,padx=25,relief="flat")
button10=Button(root,text="MC",bd=6,padx=25,relief="flat")
button11=Button(root,text="@",bd=6,padx=25,relief="flat")
button12=Button(root,text="7",bd=6,padx=25,relief="flat")
button13=Button(root,text="8",bd=6,padx=25,relief="flat")
button14=Button(root,text="9",bd=6,padx=25,relief="flat")
button15=Button(root,text="X",bd=6,padx=25,relief="flat")
button16=Button(root,text="4",bd=6,padx=25,relief="flat")
button17=Button(root,text="5",bd=6,padx=25,relief="flat")
button18=Button(root,text="6",bd=6,padx=25,relief="flat")
button19=Button(root,text="-",bd=6,padx=25,relief="flat")
button20=Button(root,text="1",bd=6,padx=25,relief="flat")
button21=Button(root,text="2",bd=6,padx=25,relief="flat")
button22=Button(root,text="3",bd=6,padx=25,relief="flat")
button23=Button(root,text="+",bd=6,padx=25,relief="flat")
button24=Button(root,text="^",bd=6,padx=25,relief="flat")
button25=Button(root,text="0",bd=6,padx=25,relief="flat")
button26=Button(root,text=".",bd=6,padx=25,relief="flat")
button27=Button(root,text="=",bd=6,padx=25,relief="flat")

button5.grid(row=2)
button6.grid(row=3,column=2)
button7.grid(row=3,column=3)
button8.grid(row=3,column=4)
button9.grid(row=2,column=4)
button10.grid(row=3)
button11.grid(row=3,column=1)
button12.grid(row=4)
button13.grid(row=4,column=1)
button14.grid(row=4,column=2)
button15.grid(row=4,column=4)
# button16
# button17
# button18
# button19
# button20
# button21
# button22
# button23
# button24
# button25
# button26
# button27










root.mainloop()