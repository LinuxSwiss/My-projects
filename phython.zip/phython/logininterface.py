from tkinter import*

root=Tk()
root.title("Login Interface")
root.configure(background="blue")

lab1= Label(root,text="Name")
lab2= Label(root,text="Password")
Button1= Button(root,bd=8,text="LOGIN")
Button2= Button(root,bd=8,text="SIGN UP")
Button3= Button(root,bd=8,text="RESET")
entry1=Entry(root)
entry2=Entry(root)


root.geometry("250x200")
lab1.grid(row=0,sticky=E)
lab2.grid(row=1,sticky=E)

entry1.grid(row=0,column=1)
entry2.grid(row=1,column=1)

Button1.grid(row=3)
Button2.grid(row=3,column=1)
Button3.grid(row=3,column=2)




root.mainloop() 